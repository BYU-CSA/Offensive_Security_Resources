from flask import Flask, request, render_template_string, redirect
import html

app = Flask(__name__)

@app.route('/')
def index():
    name = request.args.get('name', default="")

    if name == "":
        return redirect("/?name=Bob")

    return render_template_string("Hello, " + html.escape(name))

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)