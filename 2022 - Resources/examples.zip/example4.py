from flask import Flask, request

app = Flask(__name__)

accounts = [
    {"name": "Bob", "balance": 100, "password": "kjgfjdhfsal"},
    {"name": "Alice", "balance": 100, "password": "r5y4terwfds"},
    {"name": "John", "balance": 300, "password": "jkfuytregsfdvcx"},
    {"name": "Jane", "balance": 800, "password": "12qwascdx"},
    {"name": "Joe", "balance": 50, "password": "63qethgfddcv"},
    {"name": "Mary", "balance": 6000, "password": "0932oienwfksj"},
    {"name": "Mike", "balance": 0, "password": "rajfdsxnlkse98"},
    {"name": "Sue", "balance": 800, "password": "0981743259863"},
    {"name": "Tom", "balance": 1000, "password": "as0d8fhakjsndf"},
    {"name": "Tim", "balance": 1000, "password": "5w4y9298ytheraigukdsjfbzn"},
]

@app.route('/send_money')
def index():
    name = request.args.get('name', default="")
    password = request.args.get('password', default="")
    recipient = request.args.get('to', default="")
    amount = request.args.get('amt', default="")

    if (name == "") or (password == "") or (recipient == "") or (amount == ""):
        return "Please provide all parameters: name, password, to, amt"

    for account in accounts:
        if account["name"] == name:
            if account["password"] != password:
                return "Wrong password"
            if account["balance"] < int(amount):
                return "Insufficient funds"

            account["balance"] -= int(amount)

            for account in accounts:
                if account["name"] == recipient:
                    account["balance"] += int(amount)
                    return "Transfer successful"

            return "Recipient not found"
    
    return "Account not found"

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)