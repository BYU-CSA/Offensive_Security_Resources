from flask import Flask, request
from xml.dom import pulldom

app = Flask(__name__)


@app.route('/xml', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        return "Please POST an XML document to this endpoint"
    else:
        xml_input = request.get_data()
        doc = pulldom.parseString(xml_input.decode("utf-8"))
        for event, node in doc:
            doc.expandNode(node)
        return doc.pulldom.document.toprettyxml()

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)