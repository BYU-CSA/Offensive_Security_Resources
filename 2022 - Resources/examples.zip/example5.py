from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route('/base64')
def index():
    text = request.args.get('text', default="")
    return subprocess.Popen("echo " + text + " | base64", shell=True, stdout=subprocess.PIPE).stdout.read()

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)