from flask import Flask, request, Response
import requests

app = Flask(__name__)

@app.route('/picture')
def index():
    url = request.args.get('url', default="")
    
    if url == "":
        return "Please provide the url parameter for a picture"

    result = requests.get(url).text

    return Response(result, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)