from flask import Flask, request, Response, make_response
import jwt

app = Flask(__name__)

users = [
    {"userid": 0, "username": "admin", "profile": "I'm the admin!"},
    {"userid": 1, "username": "user", "profile": "Regular user"},
    {"userid": 2, "username": "guest", "profile": "Just a guest"},
    {"userid": 3, "username": "bob", "profile": "I hate Bob"},
]

SECRET = "secret"

@app.route('/')
def index():
    return_val = ""
    if 'sessionid' in request.cookies:
        session_cookie = request.cookies.get("sessionid")
        decoded = jwt.decode(session_cookie, SECRET, algorithms=["HS256"], verify=False)
        userid = int(decoded["userid"])

        if userid == -1:
            return_val = "<h1>Not logged in!</h1><br><h2>Here's your profile:</h2><p>Not logged in!</p>"
        else:
            return_val = f"<h1>Logged in! ({users[userid]['username']})</h1><br><h2>Here's your profile:</h2><p>{users[userid]['profile']}</p>"
    else:
        session_cookie = jwt.encode({"userid": "-1"}, SECRET, algorithm="HS256")
        return_val = "<h1>Not logged in!</h1><br><h2>Here's your profile:</h2><p>Not logged in!</p>"
        resp = make_response(return_val)
        resp.set_cookie('sessionid', session_cookie)
        return resp

    return return_val

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)