from flask import Flask, request

app = Flask(__name__)

users = [
    {"userid": 0, "username": "admin", "profile": "I'm the admin!"},
    {"userid": 1, "username": "user", "profile": "Regular user"},
    {"userid": 2, "username": "guest", "profile": "Just a guest"},
    {"userid": 3, "username": "bob", "profile": "I hate Bob"},
]

@app.route('/profile')
def index():
    userid_header = request.args.get('userid', default="Bad")

    # they need a userid
    if userid_header == "Bad":
        return "Error! You didn't specify a userid!"

    # userid should be integer
    try:
        userid = int(userid_header)
    except:
        return "The userid wasn't a valid integer!"

    for user in users:
        if user["userid"] == userid:
            return f"Hello, {user['username']}! Your profile is: {user['profile']}"

    return "The userid was not found"

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)