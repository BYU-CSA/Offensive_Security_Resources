from flask import Flask, request
import pickle

app = Flask(__name__)

@app.route('/')
def index():
    return_val = ""
    try:
        data = request.files.get('user_file').read()
        user_object = pickle.loads(data)
        return_val = "Hello, " + user_object['username'] + "!"
    except:
        return_val = "No pickle was uploaded to user_file"

    return return_val

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8080)