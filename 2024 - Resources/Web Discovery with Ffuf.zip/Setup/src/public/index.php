<?php
    if (isset($_POST["dev"])) {
        echo "ffuf{post_fuzzing}";
    }
    if (isset($_GET["department"])) {
        echo "ffuf{get_fuzzing}";
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to index.php</title>
</head>
<body>
    <p>
    ffuf{extension_fuzzing!}
</p>
</body>
</html>